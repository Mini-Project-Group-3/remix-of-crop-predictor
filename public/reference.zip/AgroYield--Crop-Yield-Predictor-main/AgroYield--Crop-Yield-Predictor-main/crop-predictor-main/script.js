
// Splash Screen Logic
window.addEventListener('load', () => {
    const splash = document.getElementById('splash-screen');
    if (splash) {
        setTimeout(() => {
            splash.classList.add('hidden');
        }, 2000);
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('predictionForm');
    const resultSection = document.getElementById('result');
    const resultContent = document.getElementById('resultContent');
    const yieldValueSpan = document.getElementById('yieldValue');
    const predictAgainBtn = document.getElementById('predictAgainBtn');
    const submitBtn = form.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector('.btn-text');
    const spinner = submitBtn.querySelector('.loading-spinner');

    // Handle Form Submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // 1. Basic Client-side Validation (HTML5 'required' handles most)
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        // 2. Gather Data
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Convert numbers
        data.rainfall = parseFloat(data.rainfall);
        data.temperature = parseFloat(data.temperature);
        data.area = parseFloat(data.area);

        // 3. UI: Set Loading State
        setLoading(true);
        resultSection.classList.add('hidden'); // Hide previous results

        try {
            // 4. API Request
            // Note: Replace '/predict' with full URL if backend is on a different port, e.g. 'http://localhost:5000/predict'
            // For this task, we assume the relative path or proxy is set up, or we handle the likely 404/Network error gracefully.
            const response = await fetch('/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                if (response.status === 404) {
                    throw new Error("Backend endpoint not found. Ensure backend is running.");
                }
                throw new Error('Prediction failed. Server responded with ' + response.status);
            }

            const result = await response.json();

            // 5. Display Result
            if (result.predicted_yield !== undefined) {
                // Round to 2 decimal places
                yieldValueSpan.textContent = parseFloat(result.predicted_yield).toFixed(2);
                resultSection.classList.remove('hidden');

                // Scroll to result
                resultSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                throw new Error("Invalid response format from server.");
            }

        } catch (error) {
            console.error('Error:', error);

            // DEMO MODE: If fetch fails (likely due to no backend), show a mock result for demonstration purposes
            // alerting the user so they know it's a fallback.
            // REMOVE THIS BLOCK IN PRODUCTION
            if (confirm(`Backend connection failed (${error.message}). \n\nShow demo result for visualization?`)) {
                // Simulate delay
                await new Promise(r => setTimeout(r, 1000));
                yieldValueSpan.textContent = "4.25 (Demo)";
                resultSection.classList.remove('hidden');
                resultSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                alert(`Error: ${error.message}. Please check console.`);
            }

        } finally {
            // 6. UI: Reset Loading State
            setLoading(false);
        }
    });

    // Handle "Predict Again"
    predictAgainBtn.addEventListener('click', () => {
        form.reset();
        resultSection.classList.add('hidden');
        window.scrollTo({ top: document.getElementById('predict').offsetTop, behavior: 'smooth' });
    });

    // Helper: Loading State Toggler
    function setLoading(isLoading) {
        if (isLoading) {
            submitBtn.disabled = true;
            btnText.textContent = 'Predicting...';
            spinner.classList.remove('hidden');
        } else {
            submitBtn.disabled = false;
            btnText.textContent = 'Predict Yield';
            spinner.classList.add('hidden');
        }
    }
});
