# app.py
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import uvicorn
import os

# Import the inference logic
# ensure strict import to avoid issues if other files are broken
try:
    from ml_connector import predict_yield
except ImportError:
    print("Warning: Could not import ml_connector. Prediction will fail.")
    predict_yield = lambda x: None

app = FastAPI()

# 1. CORS Configuration
# Allow all origins for development convenience
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 2. Input Data Model
class PredictionRequest(BaseModel):
    crop_type: str
    soil_type: str
    season: str
    rainfall: float
    temperature: float
    area: float

# 3. Prediction Endpoint
@app.post("/predict")
async def predict_crop_yield(data: PredictionRequest):
    # Map frontend data to the feature list expected by ml_connector/model
    # Expected features: "Nitrogen", "Phosphorus", "Potassium", "pH", "Rainfall", "Temperature", 
    #                    "District_Name", "Crop", "Fertilizer", "Soil_color", "Season", "Month"
    
    # Defaults for missing data (Generic values to allow prediction to proceed)
    # Ideally, we would ask the user for these or look them up based on Crop/Soil.
    features = {
        "Nitrogen": 100.0,      # Default approx
        "Phosphorus": 50.0,     # Default approx
        "Potassium": 50.0,      # Default approx
        "pH": 6.5,              # Neutral soil
        "Rainfall": data.rainfall,
        "Temperature": data.temperature,
        "District_Name": "Satara", # Placeholder district
        "Crop": data.crop_type,
        "Fertilizer": "Urea",   # Common fertilizer
        "Soil_color": data.soil_type, # Mapping Soil Type -> Soil_color
        "Season": data.season,
        "Month": "June"         # Approximation based on Season? Or just distinct value.
    }

    try:
        result = predict_yield(features)
        
        if result is None:
            # If the model failed (e.g., loaded incorrectly), fallback to a mock for demo
            # But prefer to raise error if strictly real.
            # User workflow expects a result. 
            print("Model returned None. Returning error.")
            raise HTTPException(status_code=500, detail="Prediction model failed to generate a result.")
            
        return {"predicted_yield": result}

    except Exception as e:
        print(f"Prediction Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# 4. Serve Static Files (Frontend)
# We serve the current directory as static to expose index.html, style.css, script.js
app.mount("/", StaticFiles(directory=".", html=True), name="static")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
